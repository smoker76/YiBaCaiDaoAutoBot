# Yi Ba Cai Dao Auto Bot

Phone-friendly Android automation project for **一把菜刀闯江湖**.

## What is included

- Java-only Android app with no runtime libraries beyond the Android SDK.
- AccessibilityService gesture automation.
- Ancient City preset based on the supplied AutoClicker profile.
- Correct handling of per-action `repeatCount` (the two double-tap actions really repeat twice).
- Coordinate scaling from the original 1440×3200 reference space to the current display.
- Optional target-package gating so the bot waits for the selected app to be foreground.
- Configurable cycle delay and maximum cycles.
- Auto Entry / Auto Sell switches are intentionally framework-only until exact detection/sell coordinates are confirmed.
- GitHub Actions workflow that builds a debug APK in the cloud.

## Build from a phone with GitHub

1. Upload the repository files to the `main` branch.
2. Open **Actions** → **Build Android Debug APK**.
3. Tap **Run workflow** (or push/commit to `main`).
4. Open the completed workflow run and download the `YiBaCaiDaoAutoBot-debug-apk` artifact.

The workflow uses current GitHub Actions for checkout/setup-java/Gradle and JDK 17. The Gradle Android plugin is pinned to 8.2.2 and the workflow installs Gradle 8.2.1.

## Install on Android

Install the generated debug APK, then enable **Yi Ba Cai Dao Auto Bot** under Android Accessibility settings. Choose the game package only after confirming its real package name. Start with the supplied Ancient City preset and verify the first cycle before unattended use.

## Safety / reliability notes

The automation sends screen-coordinate gestures. Different resolutions, aspect ratios, orientation, or game UI changes can alter where a coordinate lands. Verify the game screen and stop the bot immediately if a tap lands incorrectly.

Auto Sell and Auto Entry are not populated with guessed coordinates. They should only be implemented after the exact target screen and actions are confirmed.
