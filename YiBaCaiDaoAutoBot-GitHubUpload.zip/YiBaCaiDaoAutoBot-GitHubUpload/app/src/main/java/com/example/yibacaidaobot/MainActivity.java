package com.example.yibacaidaobot;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

import com.example.yibacaidaobot.automation.AutomationAccessibilityService;

public class MainActivity extends Activity {
    private TextView status;
    private EditText packageField;
    private EditText delayField;
    private EditText cycleCountField;
    private Switch autoEntry;
    private Switch autoSell;
    private Switch repeat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 24);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Yi Ba Cai Dao Auto Bot");
        title.setTextSize(24);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));

        TextView subtitle = new TextView(this);
        subtitle.setText("Ancient City preset • Accessibility gestures");
        subtitle.setPadding(0, 8, 0, 12);
        root.addView(subtitle);

        status = new TextView(this);
        status.setText("Accessibility: check Settings");
        status.setPadding(0, 12, 0, 12);
        root.addView(status);

        Button accessibility = new Button(this);
        accessibility.setText("Open Accessibility Settings");
        accessibility.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(accessibility);

        packageField = field("Target game package (optional; blank = any app)");
        root.addView(packageField);

        delayField = field("Cycle delay (ms)");
        delayField.setInputType(InputType.TYPE_CLASS_NUMBER);
        delayField.setText("1000");
        root.addView(delayField);

        cycleCountField = field("Max cycles (0 = unlimited)");
        cycleCountField.setInputType(InputType.TYPE_CLASS_NUMBER);
        cycleCountField.setText("10");
        root.addView(cycleCountField);

        autoEntry = new Switch(this);
        autoEntry.setText("Auto Entry (framework)");
        root.addView(autoEntry);

        autoSell = new Switch(this);
        autoSell.setText("Auto Sell (framework; coordinates unverified)");
        root.addView(autoSell);

        repeat = new Switch(this);
        repeat.setText("Run Ancient City cycle");
        repeat.setChecked(true);
        root.addView(repeat);

        Button start = new Button(this);
        start.setText("START BOT");
        start.setOnClickListener(v -> startBot());
        root.addView(start);

        Button stop = new Button(this);
        stop.setText("STOP BOT");
        stop.setOnClickListener(v -> {
            if (AutomationAccessibilityService.instance != null) {
                AutomationAccessibilityService.instance.stopBot();
            }
            status.setText("Bot stopped");
        });
        root.addView(stop);

        TextView note = new TextView(this);
        note.setText("\nPreset coordinates are scaled from 1440×3200. Verify the game layout before unattended use.\n\nAuto Entry and Auto Sell are exposed as UI/framework switches but are not populated with guessed coordinates.");
        root.addView(note);

        setContentView(scroll);
    }

    private EditText field(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        return e;
    }

    private void startBot() {
        long delay = parseLong(delayField.getText().toString(), 1000L);
        int cycles = (int) parseLong(cycleCountField.getText().toString(), 10L);
        AutomationAccessibilityService.configure(
                packageField.getText().toString().trim(),
                autoEntry.isChecked(),
                autoSell.isChecked(),
                repeat.isChecked(),
                delay,
                cycles
        );

        if (AutomationAccessibilityService.instance != null) {
            AutomationAccessibilityService.instance.startBot();
            status.setText("Bot started");
        } else {
            status.setText("Enable the Accessibility Service first.");
        }
    }

    private long parseLong(String value, long fallback) {
        try {
            return Long.parseLong(value.trim());
        } catch (Exception ignored) {
            return fallback;
        }
    }
}
