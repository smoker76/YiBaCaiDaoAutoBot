package com.example.yibacaidaobot.automation;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.List;

public class AutomationAccessibilityService extends AccessibilityService {
    public static AutomationAccessibilityService instance;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private volatile boolean running = false;
    private volatile String currentPackage = "";
    private int completedCycles = 0;

    private static String targetPackage = "";
    private static boolean autoEntry = false;
    private static boolean autoSell = false;
    private static boolean runPreset = true;
    private static long cycleDelayMs = 1000;
    private static int maxCycles = 10;

    private static final int REF_W = 1440;
    private static final int REF_H = 3200;

    public static void configure(String pkg, boolean entry, boolean sell, boolean preset, long delay, int cycles) {
        targetPackage = pkg == null ? "" : pkg;
        autoEntry = entry;
        autoSell = sell;
        runPreset = preset;
        cycleDelayMs = Math.max(100, delay);
        maxCycles = Math.max(0, cycles);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        CharSequence pkg = event.getPackageName();
        if (pkg != null) currentPackage = pkg.toString();
    }

    @Override
    public void onInterrupt() {
        stopBot();
    }

    @Override
    public void onDestroy() {
        stopBot();
        if (instance == this) instance = null;
        super.onDestroy();
    }

    public void startBot() {
        if (running) return;
        running = true;
        completedCycles = 0;
        runCycle();
    }

    public void stopBot() {
        running = false;
        handler.removeCallbacksAndMessages(null);
    }

    private boolean targetIsActive() {
        return targetPackage.isEmpty() || targetPackage.equals(currentPackage);
    }

    private boolean canRun() {
        return running && runPreset && targetIsActive();
    }

    private void runCycle() {
        if (!running) return;

        if (!targetIsActive()) {
            // Auto Entry/Sell are intentionally not guessed. Wait until the requested package is foreground.
            handler.postDelayed(this::runCycle, 500);
            return;
        }

        if (!runPreset) {
            running = false;
            return;
        }

        final List<Action> actions = ancientCityActions();
        execute(actions, 0, () -> {
            if (!running) return;
            completedCycles++;
            if (maxCycles > 0 && completedCycles >= maxCycles) {
                running = false;
                return;
            }
            handler.postDelayed(this::runCycle, cycleDelayMs);
        });
    }

    private void execute(List<Action> actions, int index, Runnable done) {
        if (!canRun() || index >= actions.size()) {
            done.run();
            return;
        }

        Action a = actions.get(index);
        int repeats = Math.max(1, a.repeatCount);
        executeRepeat(a, repeats, 0, () -> execute(actions, index + 1, done));
    }

    private void executeRepeat(Action a, int repeats, int current, Runnable nextAction) {
        if (!canRun() || current >= repeats) {
            nextAction.run();
            return;
        }

        long gestureDuration = Math.max(1, a.duration);
        Runnable afterGesture = () -> handler.postDelayed(
                () -> executeRepeat(a, repeats, current + 1, nextAction),
                40L
        );

        if (a.type == Action.TYPE_TAP) {
            tapScaled(a.x, a.y, gestureDuration, afterGesture);
        } else {
            swipeScaled(a.points, gestureDuration, afterGesture);
        }
    }

    private void tapScaled(int refX, int refY, long duration, Runnable next) {
        int[] xy = scalePoint(refX, refY);
        Path path = new Path();
        path.moveTo(xy[0], xy[1]);
        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, Math.max(1, duration));
        boolean dispatched = dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(),
                new GestureResult(next),
                null
        );
        if (!dispatched) next.run();
    }

    private void swipeScaled(int[][] refPoints, long duration, Runnable next) {
        if (refPoints == null || refPoints.length < 2) {
            next.run();
            return;
        }

        Path path = new Path();
        int[] first = scalePoint(refPoints[0][0], refPoints[0][1]);
        path.moveTo(first[0], first[1]);
        for (int i = 1; i < refPoints.length; i++) {
            int[] p = scalePoint(refPoints[i][0], refPoints[i][1]);
            path.lineTo(p[0], p[1]);
        }

        GestureDescription.StrokeDescription stroke =
                new GestureDescription.StrokeDescription(path, 0, Math.max(1, duration));
        boolean dispatched = dispatchGesture(
                new GestureDescription.Builder().addStroke(stroke).build(),
                new GestureResult(next),
                null
        );
        if (!dispatched) next.run();
    }

    private int[] scalePoint(int refX, int refY) {
        Display display = getDisplay();
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        if (display != null) {
            DisplayMetricsCompat.Size size = DisplayMetricsCompat.size(display, width, height);
            width = size.width;
            height = size.height;
        }
        int x = Math.max(0, Math.min(width - 1, Math.round(refX * (width / (float) REF_W))));
        int y = Math.max(0, Math.min(height - 1, Math.round(refY * (height / (float) REF_H))));
        return new int[]{x, y};
    }

    private static class GestureResult extends GestureDescription.GestureResultCallback {
        private final Runnable next;
        GestureResult(Runnable next) { this.next = next; }
        @Override public void onCompleted(GestureDescription g) { next.run(); }
        @Override public void onCancelled(GestureDescription g) { next.run(); }
    }

    private static class Action {
        static final int TYPE_TAP = 0;
        static final int TYPE_SWIPE = 1;
        final int type;
        final int x;
        final int y;
        final int repeatCount;
        final long duration;
        final int[][] points;

        Action(int x, int y, int repeats, long duration) {
            this.type = TYPE_TAP;
            this.x = x;
            this.y = y;
            this.repeatCount = repeats;
            this.duration = duration;
            this.points = null;
        }

        Action(int[][] points, int repeats, long duration) {
            this.type = TYPE_SWIPE;
            this.x = 0;
            this.y = 0;
            this.repeatCount = repeats;
            this.duration = duration;
            this.points = points;
        }
    }

    private List<Action> ancientCityActions() {
        List<Action> a = new ArrayList<>();
        a.add(new Action(332, 2828, 2, 145));
        a.add(new Action(855, 2270, 1, 123));
        a.add(new Action(486, 3116, 1, 116));
        a.add(new Action(750, 3124, 1, 148));
        a.add(new Action(1131, 2792, 1, 203));
        a.add(new Action(341, 2595, 1, 189));
        a.add(new Action(new int[][]{
                {185,988},{213,985},{244,983},{278,981},{324,980},{379,980},
                {443,978},{531,974},{625,968},{723,967},{816,967},{901,973},
                {981,974},{1069,979},{1209,984},{1298,982}}, 1, 381));
        a.add(new Action(241, 1117, 1, 28));
        a.add(new Action(210, 1570, 1, 10));
        a.add(new Action(208, 1780, 1, 44));
        a.add(new Action(397, 1122, 1, 108));
        a.add(new Action(225, 1425, 1, 110));
        a.add(new Action(211, 1783, 1, 219));
        a.add(new Action(649, 1118, 1, 63));
        a.add(new Action(208, 1416, 1, 155));
        a.add(new Action(204, 1742, 1, 325));
        a.add(new Action(839, 1109, 1, 83));
        a.add(new Action(216, 1403, 1, 131));
        a.add(new Action(213, 1742, 1, 245));
        a.add(new Action(1024, 1115, 1, 109));
        a.add(new Action(215, 1416, 1, 134));
        a.add(new Action(213, 1736, 1, 292));
        a.add(new Action(208, 1783, 1, 68));
        a.add(new Action(1329, 2611, 1, 10));
        a.add(new Action(798, 2632, 1, 10));
        a.add(new Action(746, 2992, 1, 10));
        a.add(new Action(829, 2585, 1, 10));
        a.add(new Action(178, 2013, 1, 10));
        a.add(new Action(1327, 2619, 1, 10));
        a.add(new Action(563, 506, 2, 10));
        return a;
    }

    /** Small compatibility helper to avoid depending on AndroidX DisplayMetrics APIs. */
    private static final class DisplayMetricsCompat {
        static Size size(Display display, int fallbackW, int fallbackH) {
            android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
            display.getRealMetrics(dm);
            int w = dm.widthPixels > 0 ? dm.widthPixels : fallbackW;
            int h = dm.heightPixels > 0 ? dm.heightPixels : fallbackH;
            return new Size(w, h);
        }
        static final class Size {
            final int width;
            final int height;
            Size(int width, int height) { this.width = width; this.height = height; }
        }
    }
}
